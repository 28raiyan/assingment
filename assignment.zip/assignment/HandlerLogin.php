<?php
	session_start();
	
	$username = $_POST['username'];
    $password = $_POST['password'];

    $ok = true;
    $invalid = false;

    if(!$username){
        echo "Please Enter UserName<br>";        
        $ok = false;
    }
    if(strlen($password)<1){
        echo "Please Enter Password<br>";
        $ok = false;   
    }

    if($ok){
        foreach($_SESSION["users"] as $user){
            if($user["username"]===$username && $user["password"]===$password){
                $_SESSION['current']= $user;
                header("location: Dashboard.php");
            }
            else{
                $invalid  = true;
            }
        }
    }

    if($invalid){
        echo "Invalid Login<br>";
    }

?>