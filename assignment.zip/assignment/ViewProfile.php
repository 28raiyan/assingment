<?php session_start(); ?>

<html> 
<head>
    <title> home page | X company </title>
</head> 
<body> 
    <font face="arial"> 
    <table width="80%" border="1px solid black" align="center"> 
        <tr height="60px" colspan="2">
            <th>
                   <img src="Xcompany.png" align="left" />

            <p align="right" padding="10px">
                Hello 
                <a href="EditProfile.php">  <?php echo $_SESSION['current']['username'];?> </a> | 
                <a href="index.php"> logout </a>  
            </p> 
            </th>
            
        </tr>

        <tr>
            <td colspan="2" height="300"> 
                <table width="100%" height="100%" border="1px solid black">
                    <tr>
                        <td width="20%"> 
                            <p align="center"> Account </p>
                            <hr/> 
                            <ul>
                                <li> <a href="dashboard.php">  Dashboard </a> </li>
                                <li> <a href="ViewProfile.php"> View Profile </a> </li>
                                <li> <a href="EditProfile.php"> Edit Profile </a> </li>
                                <li> <a href="changepass.php"> Change Password </a> </li>
                                <li> <a href="chagepic.php"> Change Profile pic </a> </li>
                                <li> <a href="index.php"> logout  </a> </li>
                            </ul>
                        </td>
                        <td align="center">
                          
                        <table align="center" width="70%">
                <td align="center">
                    <form action="RegistrationHandler.php">
                    <fieldset>            
                        <legend>PROFILE</legend>
                        <table>
                            <tr>
                                <td>Name</td>
                                <td>: <b>Asif </b></td>
                                <td rowspan="7" align="center">
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <img src="profile.png" height="100px"><br>
                                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <a href="ProfilePicture.php">Change</a>
                                </td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td>Email</td>
                                <td>: <b> Asif0531@live.com</b></td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td>Gender</td>
                                <td>: <b> male</b></td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td>Date of Birth</td>
                                <td>: 
                                    <b>11</b> /
                                    <b>11</b> / 
                                    <b>1990</b>
                                </td>
                            </tr>
                            <tr><td colspan="3"><hr></td></tr>
                            <tr>
                                <td><a href="chagepic.php">Edit Profile</a></td>
                                
                            </tr>
                            
                        </table>
                    </fieldset>
                    </form>
                </td>
            </table>

                        </td>

                    </tr>
                </table>
                
             </td>
            
        </tr>

        <tr>
            <td colspan="2">
                     <p align="center">   Copyright &copy;  2017 </p>  
            </td>
             
        </tr>
    </table> 
    </font>
</body> 
</html> 
