<html> 

<head>
    <title> Login page  </title>
</head>


<body>
 <font face="arial"> 
        <table width="80%" border="1px solid black" align="center"> 
            <tr height="60px" colspan="2">
                <th>
                   <img src="Xcompany.png" align="left" />


                <p align="right" padding="10px">
                   <a href="index.php"> Home </a> | 
                   <a href="login.php"> Login </a> | 
                   <a href="registration.php"> Registration </a>  
               </p> 
                </th>
                
            </tr>

            <tr>
                <td colspan="2" height="300"> 
                <table align="center">
                    <td align="center">
                        <form action="HandlerLogin.php" method="POST">
                            <fieldset>
                                <legend>LOGIN</legend>
                                <table>
                                    <tr>
                                        <td>User Name</td>
                                        <td>: <input name="username"></td>
                                    </tr>
                                    <tr>
                                        <td>Password</td>
                                        <td>: <input type="password" name="password"> </td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><hr></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><input type="checkbox" name="remember">Remeber Me <br></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <br>
                                            <input type="submit">&nbsp;&nbsp;<a href="">Forget Password? </a>
                                        </td>
                                    </tr>
                                </table>
                            </fieldset>
                        </form>
                    </td>
                </table>
                    
                 </td>
                
            </tr>

            <tr>
                <td colspan="2">
                         <p align="center">   Copyright &copy;  2017 </p>  
                </td>
                 
            </tr>
        </table> 
        </font>
    </body> 

</<html


