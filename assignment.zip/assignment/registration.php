<html> 

<head>
    <title> Registration page  </title>
</head>


<body>
 <font face="arial"> 
        <table width="80%" border="1px solid black" align="center"> 
            <tr height="60px" colspan="2">
                <th>
                   <img src="Xcompany.png" align="left" />


                <p align="right" padding="10px">
                   <a href="index.php"> Home </a> | 
                   <a href="login.php"> Login </a> | 
                   <a href="registration.php"> Registration </a>  
               </p> 
                </th>
                
            </tr>

            <tr>
                <td colspan="2" height="300"> 
                <table align="center">
                    <td align="center">
                            <form action="HandalerRegistration.php" method="POST">
                            <fieldset>            
                                <legend>REGISTRATION</legend>
                                <table>
                                    <tr>
                                        <td>Name</td>
                                        <td>:<input name="name"></td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td>Email</td>
                                        <td>:<input name="email">
                                        <abbr title="hint : asif0531@live.com"> 
                                        <img src="https://cdn2.iconfinder.com/data/icons/perfect-flat-icons-2/512/Info_information_user_about_card_button_symbol.png"  height="15px"/>
                                        </abbr>
                                    </td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td>User Name</td>
                                        <td>:<input name="username"></td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td>Password</td>
                                        <td>:<input type="password" name="password"></td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td>Conform Password</td>
                                        <td>:<input type="password" name="cpassword"></td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td colspan="2">
                                            <fieldset>
                                                <legend>Gender</legend>
                                                <input type="radio" name="gender" value="Male">   Male
                                                <input type="radio" name="gender" value="Female"> Female
                                                <input type="radio" name="gender" value="Other">  Other
                                            </fieldset>
                                        </td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td colspan="2">
                                            <fieldset>
                                                <legend>Date of Birth</legend>
                                                <input name="date"  size="7">/
                                                <input name="month" size="7">/
                                                <input name="year"  size="7"> (dd/mm/yy)
                                            </fieldset>
                                        </td>
                                    </tr>
                                    <tr><td colspan="2"><hr></td></tr>
                                    <tr>
                                        <td><input type="submit"> <input type="reset"></td>
                                    </tr>
                                </table>
                            </fieldset>
                        </form>
                    </td>
                </table>
                    
                 </td>
                
            </tr>

            <tr>
                <td colspan="2">
                         <p align="center">   Copyright &copy;  2017 </p>  
                </td>
                 
            </tr>
        </table> 
        </font>
    </body> 

</<html


