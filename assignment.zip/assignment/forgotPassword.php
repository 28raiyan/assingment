<html> 

<head>
    <title> forgot password </title>
</head>


<body>
 <font face="arial"> 
        <table width="80%" border="1px solid black" align="center"> 
            <tr height="60px" colspan="2">
                <th>
                   <img src="Xcompany.png" align="left" />


                <p align="right" padding="10px">
                   <a href="index.php"> Home </a> | 
                   <a href="login.php"> Login </a> | 
                   <a href="registration.php"> Registration </a>  
               </p> 
                </th>
                
            </tr>

            <tr>
                <td colspan="2" height="300"> 
                <table align="center">
                    <td align="center">
                        <form action="loginHandler.php">
                            <fieldset>
                                <legend>FORGOT PASSWORD</legend>
                                <table>
                                    <tr>
                                        <td>Enter Email</td>
                                        <td>: <input name="email"></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2"><hr></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">
                                            <br>
                                            <input type="submit">
                                        </td>
                                    </tr>
                                </table>
                            </fieldset>
                        </form>
                    </td>
                </table>
                    
                 </td>
                
            </tr>

            <tr>
                <td colspan="2">
                         <p align="center">   Copyright &copy;  2017 </p>  
                </td>
                 
            </tr>
        </table> 
        </font>
    </body> 

</<html


