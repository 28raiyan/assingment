 <html> 
    <head>
        <title> home page | X company </title>
    </head> 
    <body> 
        <font face="arial"> 
        <table width="80%" border="1px solid black" align="center"> 
            <tr height="60px" colspan="2">
                <th>
                  
                       <img src="Xcompany.png" align="left" /> 
                 


                <p align="right" padding="10px">
                    <a href="index.php"> Home </a> | 
                    <a href="login.php"> Login </a> | 
                    <a href="registration.php"> Registration </a>  
                </p> 
                </th>
                
            </tr>

            <tr>
                <td colspan="2" height="300"> 
                    <h3 align="center"> Welcome to X company </h3> 
                    
                 </td>
                
            </tr>

            <tr>
                <td colspan="2">
                         <p align="center">   Copyright &copy;  2017 </p>  
                </td>
                 
            </tr>
        </table> 
        </font>
    </body> 
 </html> 
