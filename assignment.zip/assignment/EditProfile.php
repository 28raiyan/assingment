<?php session_start(); ?>
<html> 
<head>
    <title> home page | X company </title>
</head> 
<body> 
    <font face="arial"> 
    <table width="80%" border="1px solid black" align="center"> 
        <tr height="60px" colspan="2">
            <th>
                   <img src="Xcompany.png" align="left" />

            <p align="right" padding="10px">
            Hello 
            <a href="EditProfile.php">  <?php echo $_SESSION['current']['username'];?> </a> | 
                <a href="index.php"> logout </a>  
            </p> 
            </th>
            
        </tr>

        <tr>
            <td colspan="2" height="300"> 
                <table width="100%" height="100%" border="1px solid black">
                    <tr>
                        <td width="20%"> 
                            <p align="center"> Account </p>
                            <hr/> 
                            <ul>
                                <li> <a href="dashboard.php">  Dashboard </a> </li>
                                <li> <a href="ViewProfile.php"> View Profile </a> </li>
                                <li> <a href="EditProfile.php"> Edit Profile </a> </li>
                                <li> <a href="changepass.php"> Change Password </a> </li>
                                <li> <a href="chagepic.php"> Change Profile pic </a> </li>
                                <li> <a href="index.php"> logout  </a> </li>

                            </ul>
                        </td>
                        <td align="center">
                          
                        <table align="center" width="70%">
                <td align="center">
                    <form action="EditProfileHandler.php" method="POST">
                    <fieldset>            
                        <legend>EDIT PROFILE</legend>
                        <table>
                            <tr>
                                <td>Name</td>
                                <td>:<input name="name" value="<?php echo $_SESSION['current']['name'];?>"></td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td>Email</td>
                                <td>:<input name="email" value="<?php echo $_SESSION['current']['email'];?>"></td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td>Gender</td>
                                <td>:
                                    <input type="radio" name="gender" value="Male" <?php echo ($_SESSION['current']['gender'])==="Male" ? "checked":"";?>> Male
                                    <input type="radio" name="gender" value="Female" <?php echo ($_SESSION['current']['gender'])==="Female" ? "checked":"";?>> Female
                                    <input type="radio" name="gender" value="Other" <?php echo isset($_SESSION['current']['gender'])==="Other" ? "checked":"";?>>  Other
                                </td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td></td>
                                <td>
                                    &nbsp;
                                    date 
                                    &nbsp;&nbsp;&nbsp;
                                    month
                                    &nbsp;&nbsp;
                                    year
                                </td>
                            </tr>
                            <tr>
                                <td>Date of Birth</td>
                                <td>:
                                    <input name="date"  size="4" value="<?php echo $_SESSION['current']['date'];?>">/
                                    <input name="month" size="4" value="<?php echo $_SESSION['current']['month'];?>">/
                                    <input name="year"  size="4" value="<?php echo $_SESSION['current']['year'];?>">
                                </td>
                            </tr>
                            <tr><td colspan="2"><hr></td></tr>
                            <tr>
                                <td><input type="submit">
                            </tr>
                        </table>
                    </fieldset>
                    </form>
                </td>
            </table>
                        </td>

                    </tr>
                </table>
                
             </td>
            
        </tr>

        <tr>
            <td colspan="2">
                     <p align="center">   Copyright &copy;  2017 </p>  
            </td>
             
        </tr>
    </table> 
    </font>
</body> 
</html> 
